#ifndef CA_CLIENT_H
#define CA_CLIENT_H

extern int ca_client_setup(struct asfd *asfd, struct conf **confs);

#endif
