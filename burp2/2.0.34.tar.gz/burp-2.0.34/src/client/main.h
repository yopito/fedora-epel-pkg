#ifndef _CLIENT_MAIN_H
#define _CLIENT_MAIN_H

extern int client(struct conf **confs, enum action act, int vss_restore);

#endif
