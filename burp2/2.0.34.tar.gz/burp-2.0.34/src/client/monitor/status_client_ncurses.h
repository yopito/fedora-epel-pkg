#ifndef STATUS_CLIENT_NCURSES_H
#define STATUS_CLIENT_NCURSES_H

#include "../../action.h"

extern int status_client_ncurses(enum action act, struct conf **confs);

#endif
