#ifndef _BACKUP_PHASE2_CLIENT_PROTOCOL1_H
#define _BACKUP_PHASE2_CLIENT_PROTOCOL1_H

extern int backup_phase2_client_protocol1(struct asfd *asfd,
	struct conf **confs, int resume);

#endif
