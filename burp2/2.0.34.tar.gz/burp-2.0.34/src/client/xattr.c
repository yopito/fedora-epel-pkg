#include "../burp.h"
#include "../alloc.h"
#include "../asfd.h"
#include "../async.h"
#include "../cntr.h"
#include "../log.h"
#include "../prepend.h"
#include "extrameta.h"
#include "xattr.h"

#ifdef HAVE_SYS_XATTR_H
#include <sys/xattr.h>
#endif

#ifdef HAVE_SYS_EXTATTR_H
#include <sys/extattr.h>
#endif
#ifdef HAVE_LIBUTIL_H
#include <libutil.h>
#endif

#ifdef HAVE_XATTR

#if defined(HAVE_DARWIN_OS)

/*
 * OSX doesn't have llistxattr, lgetxattr and lsetxattr but has
 * listxattr, getxattr and setxattr with an extra options argument
 * which mimics the l variants of the functions when we specify
 * XATTR_NOFOLLOW as the options value.
 */
#define llistxattr(path, list, size) \
listxattr((path), (list), (size), XATTR_NOFOLLOW)
#define lgetxattr(path, name, value, size) \
getxattr((path), (name), (value), (size), 0, XATTR_NOFOLLOW)
#define lsetxattr(path, name, value, size, flags) \
setxattr((path), (name), (value), (size), (flags), XATTR_NOFOLLOW)


static const char *xattr_acl_skiplist[2] = {
    "com.apple.system.Security",
    NULL
};
#endif // HAVE_DARWIN_OS

#if defined(HAVE_LINUX_OS)
static const char *xattr_acl_skiplist[3] = {
    "system.posix_acl_access",
    "system.posix_acl_default",
    NULL
};
#endif // HAVE_LINUX_OS

#if defined(HAVE_FREEBSD_OS)
static const char *acl_skiplist[2] = {
    "system.posix1e.acl_access", NULL
};
#endif // HAVE_FREEBSD_OS

#if defined(HAVE_NETBSD_OS)
static const char *acl_skiplist[1] = { NULL };
#endif // HAVE_NETBSD_OS

#ifndef UTEST
static
#endif
char *get_next_xattr_str(struct asfd *asfd, char **data, size_t *l,
	struct cntr *cntr, ssize_t *s, const char *path)
{
	char *ret=NULL;

	if((sscanf(*data, "%08X", (unsigned int *)s))!=1)
	{
		logw(asfd, cntr, "sscanf of xattr '%s' %zd failed for %s\n",
			*data, *l, path);
		return NULL;
	}
	*data+=8;
	*l-=8;
	if(!(ret=(char *)malloc_w((*s)+1, __func__)))
		return NULL;
	memcpy(ret, *data, *s);
	ret[*s]='\0';

	*data+=*s;
	*l-=*s;

	return ret;
}

#if defined(HAVE_SYS_EXTATTR_H)
static int namespaces[2] = {
	EXTATTR_NAMESPACE_USER,
	EXTATTR_NAMESPACE_SYSTEM
};

int has_xattr(const char *path)
{
	int i=0;
	for(i=0; i<(int)(sizeof(namespaces)/sizeof(int)); i++)
	{
		if(extattr_list_link(path, namespaces[i], NULL, 0)>0)
			return 1;
	}
	return 0;
}

#define BSD_BUF_SIZE	1024
int get_xattr(struct asfd *asfd, const char *path,
	char **xattrtext, size_t *xlen, struct cntr *cntr)
{
	int i=0;
	ssize_t maxlen=0xFFFFFFFF/2;

	for(i=0; i<(int)(sizeof(namespaces)/sizeof(int)); i++)
	{
		int j=0;
		ssize_t len=0;
		int have_acl=0;
		char *xattrlist=NULL;
		char *cnamespace=NULL;
		ssize_t totallen=0;
		char *toappend=NULL;
		char z[BSD_BUF_SIZE]="";
		char cattrname[BSD_BUF_SIZE]="";
		if((len=extattr_list_link(path, namespaces[i], NULL, 0))<0)
		{
			logw(asfd, cntr, "could not extattr_list_link of '%s': %zd\n",
				path, len);
			return 0; // carry on
		}
		if(!len) continue;
		if(xattrtext && *xattrtext)
		{
			// Already have some meta text, which means that some
			// ACLs were set.
			have_acl++;
		}
		if(!(xattrlist=(char *)calloc_w(1, len+1, __func__)))
			return -1;
		if((len=extattr_list_link(path, namespaces[i], xattrlist, len))<=0)
		{
			logw(asfd, cntr, "could not extattr_list_link '%s': %zd\n",
				path, len);
			free_w(&xattrlist);
			return 0; // carry on
		}
		xattrlist[len]='\0';

		if(extattr_namespace_to_string(namespaces[i], &cnamespace))
		{
			logp("Failed to convert %d into namespace on '%s'\n",
				 namespaces[i], path);
			free_w(&xattrlist);
			return 0; // carry on
		}


		for(j=0; j<(int)len; j+=xattrlist[j]+1)
		{
			int cnt=0;
			char tmp1[9];
			char tmp2[9];
			size_t newlen=0;
			size_t zlen=0;
			ssize_t vlen=0;
			char *val=NULL;
			cnt=xattrlist[j];
			if(cnt>((int)sizeof(cattrname)-1))
				cnt=((int)sizeof(cattrname)-1);
			strncpy(cattrname, xattrlist+(j+1), cnt);
			cattrname[cnt]='\0';
			snprintf(z, sizeof(z), "%s.%s",
				cnamespace, cattrname);

			if(have_acl)
			{
				int c=0;
				int skip=0;
				// skip xattr entries that were already saved
				// as ACLs.
				for(c=0; acl_skiplist[c]; c++)
				{
					if(!strcmp(z, acl_skiplist[c]))
					{
						skip++;
						break;
					}
				}
				if(skip) continue;
			}
			zlen=strlen(z);
			//printf("\ngot: %s (%s)\n", z, path);

			if((vlen=extattr_list_link(path, namespaces[i],
				xattrlist, len))<0)
			{
				logw(asfd, cntr, "could not extattr_list_link on %s for %s: %zd\n", path, cnamespace, vlen);
				continue;
			}
			if(vlen)
			{
				if(!(val=(char *)malloc_w(vlen+1, __func__)))
				{
					free_w(&xattrlist);
					free_w(&toappend);
					return -1;
				}
				if((vlen=extattr_get_link(path, namespaces[i],
					cattrname, val, vlen))<0)
				{
					logw(asfd, cntr, "could not extattr_list_link %s for %s: %zd\n", path, cnamespace, vlen);
					free_w(&val);
					continue;
				}
				val[vlen]='\0';

				if(vlen>maxlen)
				{
					logw(asfd, cntr, "xattr value of '%s' too long: %zd\n",
						path, vlen);
					free_w(&toappend);
					free_w(&val);
					break;
				}
			}

			snprintf(tmp1, sizeof(tmp1), "%08X", (unsigned int)zlen);
			snprintf(tmp2, sizeof(tmp2), "%08X", (unsigned int)vlen);
			newlen=totallen+8+zlen+8+vlen;
			if(!(toappend=(char *)realloc_w(toappend, newlen, __func__)))
			{
				free_w(&val);
				free_w(&xattrlist);
				return -1;
			}
			memcpy(toappend+totallen, tmp1, 8);
			totallen+=8;
			memcpy(toappend+totallen, z, zlen);
			totallen+=zlen;
			memcpy(toappend+totallen, tmp2, 8);
			totallen+=8;
			memcpy(toappend+totallen, val, vlen);
			totallen+=vlen;
			free_w(&val);

			if(totallen>maxlen)
			{
				logw(asfd, cntr,
				  "xattr length of '%s' grew too long: %lu\n",
				  path, (unsigned long)totallen);
				free_w(&val);
				free_w(&toappend);
				free_w(&xattrlist);
				return 0; // carry on
			}
		}

		if(toappend)
		{
			char tmp3[10];
			size_t newlen=0;
			snprintf(tmp3, sizeof(tmp3), "%c%08X",
				META_XATTR_BSD, (unsigned int)totallen);
			newlen=(*xlen)+9+totallen;
			if(!(*xattrtext=(char *)
				realloc_w(*xattrtext, newlen, __func__)))
			{
				free_w(&toappend);
				free_w(&xattrlist);
				return -1;
			}
			memcpy(*xattrtext, tmp3, 9);
			(*xlen)+=9;
			memcpy((*xattrtext)+(*xlen), toappend, totallen);
			(*xlen)+=totallen;
			free_w(&toappend);
		}
		free_w(&xattrlist);
	}

	return 0;
}

static int do_set_xattr_bsd(struct asfd *asfd,
	const char *path,
	const char *xattrtext, size_t xlen, struct cntr *cntr)
{
	int ret=-1;
	size_t l=0;
	char *data=NULL;
	char *value=NULL;
	char *nspace=NULL;

	data=(char *)xattrtext;
	l=xlen;
	while(l>0)
	{
		ssize_t cnt;
		ssize_t vlen=0;
		int cnspace=0;
		char *name=NULL;

		if(!(nspace=get_next_xattr_str(asfd, &data, &l,
			cntr, &vlen, path))
		  || !(value=get_next_xattr_str(asfd, &data, &l,
			cntr, &vlen, path)))
				goto end;

		// Need to split the name into two parts.
		if(!(name=strchr(nspace, '.')))
		{
			logw(asfd, cntr,
			  "could not split %s into namespace and name on %s\n",
				nspace, path);
			goto end;
		}
		*name='\0';
		name++;

		if(extattr_string_to_namespace(nspace, &cnspace))
		{
			logw(asfd, cntr,
				"could not convert %s into namespace on %s\n",
				nspace, path);
			goto end;
		}

		//printf("set_link: %d %s %s %s\n", cnspace, nspace, name, value);
		if((cnt=extattr_set_link(path,
			cnspace, name, value, vlen))!=vlen)
		{
			logw(asfd, cntr,
				"extattr_set_link error on %s %zd!=%zd: %s\n",
				path, cnt, vlen, strerror(errno));
			goto end;
		}

		free_w(&nspace);
		free_w(&value);
	}
	ret=0;
end:
	free_w(&nspace);
	free_w(&value);
	return ret;
}

int set_xattr(struct asfd *asfd, const char *path,
	const char *xattrtext,
	size_t xlen, char metacmd, struct cntr *cntr)
{
	switch(metacmd)
	{
		case META_XATTR_BSD:
			return do_set_xattr_bsd(asfd, path,
				xattrtext, xlen, cntr);
		default:
			logp("unknown xattr type: %c\n", metacmd);
			logw(asfd, cntr, "unknown xattr type: %c\n", metacmd);
			break;
	}
	return -1;
}
#elif defined(HAVE_SYS_XATTR_H)
int has_xattr(const char *path)
{
	if(llistxattr(path, NULL, 0)>0) return 1;
	return 0;
}

int get_xattr(struct asfd *asfd, const char *path,
	char **xattrtext, size_t *xlen, struct cntr *cntr)
{
	char *z=NULL;
	ssize_t len;
	int have_acl=0;
	char *toappend=NULL;
	char *xattrlist=NULL;
	ssize_t totallen=0;
	ssize_t maxlen=0xFFFFFFFF/2;

	if((len=llistxattr(path, NULL, 0))<0)
	{
		logw(asfd, cntr, "could not llistxattr '%s': %zd %s\n",
			path, len, strerror(errno));
		return 0; // carry on
	}
	if(!(xattrlist=(char *)calloc_w(1, len, __func__)))
		return -1;
	if((len=llistxattr(path, xattrlist, len))<0)
	{
		logw(asfd, cntr, "could not llistxattr '%s': %zd %s\n",
			path, len, strerror(errno));
		free_w(&xattrlist);
		return 0; // carry on
	}

	if(xattrtext && *xattrtext)
	{
		// Already have some meta text, which means that some
		// ACLs were set.
		have_acl++;
	}

	for(z=xattrlist; z-xattrlist <= len; z=strchr(z, '\0')+1)
	{
		char tmp1[9];
		char tmp2[9];
		char *val=NULL;
		ssize_t vlen;
		ssize_t zlen=0;
		ssize_t newlen=0;

		if((zlen=strlen(z))>maxlen)
		{
			logw(asfd, cntr, "xattr element of '%s' too long: %zd\n",
				path, zlen);
			free_w(&toappend);
			break;
		}

		if(have_acl)
		{
			int c=0;
			int skip=0;
			// skip xattr entries that were already saved as ACLs.
			for(c=0; xattr_acl_skiplist[c]; c++)
			{
				if(!strcmp(z, xattr_acl_skiplist[c]))
				{
					skip++;
					break;
				}
			}
			if(skip) continue;
		}

		if((vlen=lgetxattr(path, z, NULL, 0))<0)
		{
			logw(asfd, cntr,
				"could not lgetxattr on %s for %s: %zd %s\n",
				path, z, vlen, strerror(errno));
			continue;
		}
		if(vlen)
		{
			if(!(val=(char *)malloc_w(vlen+1, __func__)))
			{
				free_w(&xattrlist);
				free_w(&toappend);
				return -1;
			}
			if((vlen=lgetxattr(path, z, val, vlen))<0)
			{
				logw(asfd, cntr,
				  "could not lgetxattr %s for %s: %zd %s\n",
					path, z, vlen, strerror(errno));
				free_w(&val);
				continue;
			}
			val[vlen]='\0';

			if(vlen>maxlen)
			{
				logw(asfd, cntr,
					"xattr value of '%s' too long: %zd\n",
					path, vlen);
				free_w(&toappend);
				free_w(&val);
				break;
			}
		}

		snprintf(tmp1, sizeof(tmp1), "%08X", (unsigned int)zlen);
		snprintf(tmp2, sizeof(tmp2), "%08X", (unsigned int)vlen);
		newlen=totallen+8+zlen+8+vlen;
		if(!(toappend=(char *)realloc_w(toappend, newlen, __func__)))
		{
			free_w(&val);
			free_w(&xattrlist);
			return -1;
		}
		memcpy(toappend+totallen, tmp1, 8);
		totallen+=8;
		memcpy(toappend+totallen, z, zlen);
		totallen+=zlen;
		memcpy(toappend+totallen, tmp2, 8);
		totallen+=8;
		memcpy(toappend+totallen, val, vlen);
		totallen+=vlen;
		free_w(&val);

		if(totallen>maxlen)
		{
			logw(asfd, cntr,
				"xattr length of '%s' grew too long: %zd\n",
				path, totallen);
			free_w(&val);
			free_w(&toappend);
			free_w(&xattrlist);
			return 0; // carry on
		}
	}

	if(toappend)
	{
		char tmp3[10];
		size_t newlen=0;
		snprintf(tmp3, sizeof(tmp3), "%c%08X",
			META_XATTR, (unsigned int)totallen);
		newlen=(*xlen)+9+totallen;
		if(!(*xattrtext=(char *)
			realloc_w(*xattrtext, newlen, __func__)))
		{
			free_w(&toappend);
			free_w(&xattrlist);
			return -1;
		}
		memcpy(*xattrtext, tmp3, 9);
		(*xlen)+=9;
		memcpy((*xattrtext)+(*xlen), toappend, totallen);
		(*xlen)+=totallen;
		free_w(&toappend);
	}
	free_w(&xattrlist);
	return 0;
}

static int do_set_xattr(struct asfd *asfd,
	const char *path,
	const char *xattrtext, size_t xlen, struct cntr *cntr)
{
	size_t l=0;
	int ret=-1;
	char *data=NULL;
	char *name=NULL;
	char *value=NULL;

	data=(char *)xattrtext;
	l=xlen;
	while(l>0)
	{
		ssize_t s=0;
		free_w(&name);
		free_w(&value);

		if(!(name=get_next_xattr_str(asfd, &data, &l,
			cntr, &s, path))
		  || !(value=get_next_xattr_str(asfd, &data, &l,
			cntr, &s, path)))
				goto end;
		if(lsetxattr(path, name, value, s, 0))
		{
			logw(asfd, cntr, "lsetxattr error on %s: %s\n",
				path, strerror(errno));
			goto end;
		}
	}

	ret=0;
end:
	free_w(&name);
	free_w(&value);
	return ret;
}

int set_xattr(struct asfd *asfd, const char *path,
	const char *xattrtext, size_t xlen, char metacmd, struct cntr *cntr)
{
	switch(metacmd)
	{
		case META_XATTR:
			return do_set_xattr(asfd,
				path, xattrtext, xlen, cntr);
		default:
			logp("unknown xattr type: %c\n", metacmd);
			logw(asfd, cntr, "unknown xattr type: %c\n", metacmd);
			break;
	}
	return -1;
}
#endif // HAVE_SYS_XATTR_H

#endif // HAVE_XATTR
