#ifndef _EXTRA_COMMS_H
#define _EXTRA_COMMS_H

extern int extra_comms(struct async *as, char **incexc,
	int *srestore, struct conf **confs, struct conf **cconfs);

#endif
