#ifndef _AUTOUPGRADE_CLIENT_H
#define _AUTOUPGRADE_CLIENT_H

extern int autoupgrade_client(struct async *as, struct conf **confs);

#endif
