#ifndef _MONITOR_CLIENT_H
#define _MONITOR_CLIENT_H

extern int do_monitor_client(struct asfd *asfd, struct conf **confs);

#endif
