#ifndef _BROWSE_H
#define _BROWSE_H

extern int browse_manifest(struct asfd *srfd, struct cstat *cstat,
	struct bu *bu, const char *browse, int use_cache);

#endif
