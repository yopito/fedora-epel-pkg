#ifndef STATUS_SERVER_H
#define STATUS_SERVER_H

extern int status_server(struct async *as, struct conf **confs);

#endif
