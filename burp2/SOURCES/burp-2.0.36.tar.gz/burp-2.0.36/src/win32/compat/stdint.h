#ifdef __GNUC__
#include_next <stdint.h>
#endif
