#ifndef _AUTH_CLIENT_H
#define _AUTH_CLIENT_H

extern int authorise_client(struct config *conf, char **server_version, struct cntr *p1cntr);

#endif // _AUTH_CLIENT_H
