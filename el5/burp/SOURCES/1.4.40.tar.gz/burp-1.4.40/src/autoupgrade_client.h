#ifndef _AUTOUPGRADE_CLIENT_H
#define _AUTOUPGRADE_CLIENT_H

extern int autoupgrade_client(struct config *conf, struct cntr *p1cntr);

#endif // _AUTOUPGRADE_CLIENT_H
