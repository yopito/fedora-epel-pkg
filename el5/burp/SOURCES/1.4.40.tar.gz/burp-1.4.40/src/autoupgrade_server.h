#ifndef _AUTOUPGRADE_SERVER_H
#define _AUTOUPGRADE_SERVER_H

extern int autoupgrade_server(long ser_ver, long cli_ver, const char *os, struct config *conf, struct cntr *p1cntr);

#endif // _AUTOUPGRADE_SERVER_H
