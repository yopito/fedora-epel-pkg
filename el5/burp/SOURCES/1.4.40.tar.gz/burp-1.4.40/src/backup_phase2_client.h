#ifndef BACKUP_PHASE2_CLIENT_H
#define BACKUP_PHASE2_CLIENT_H

extern int backup_phase2_client(struct config *conf, struct cntr *p1cntr, int resume, struct cntr *cntr);

#endif
