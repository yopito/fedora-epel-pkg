#ifndef _BACKUP_PHASE4_SERVER_H
#define _BACKUP_PHASE4_SERVER_H

extern int backup_phase4_server(const char *basedir, const char *working, const char *current, const char *currentdata, const char *finishing, struct config *cconf, const char *client, struct cntr *p1cntr, struct cntr *cntr);

#endif // _BACKUP_PHASE4_SERVER_H
