#ifndef CA_CLIENT_H
#define CA_CLIENT_H

extern int ca_client_setup(struct config *conf, struct cntr *p1cntr);

#endif
