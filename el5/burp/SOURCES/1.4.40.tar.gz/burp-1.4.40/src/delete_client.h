#ifndef _DELETE_CLIENT_H
#define _DELETE_CLIENT_H

extern int do_delete_client(struct config *conf);

#endif // _DELETE_CLIENT_H
