#ifndef _DELETE_SERVER_H
#define _DELETE_SERVER_H

extern int do_delete_server(const char *basedir, const char *backup, const char *client, struct cntr *p1cntr, struct cntr *cntr, struct config *cconf);

#endif // _DELETE_SERVER_H
