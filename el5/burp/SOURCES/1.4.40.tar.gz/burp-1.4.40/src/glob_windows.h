#ifndef WINDOWN_GLOB_H
#define WINDOWN_GLOB_H

extern int windows_glob(struct config *conf, struct strlist ***ielist);

#endif
