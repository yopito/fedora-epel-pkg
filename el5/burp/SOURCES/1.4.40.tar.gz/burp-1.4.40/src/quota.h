#ifndef _QUOTA_H
#define _QUOTA_H

extern int check_quota(struct config *conf, struct cntr *p1cntr);

#endif
