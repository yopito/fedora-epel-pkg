#ifndef STATUS_CLIENT_H
#define STATUS_CLIENT_H

extern int status_client_ncurses(struct config *conf, enum action act, const char *sclient);

#endif
