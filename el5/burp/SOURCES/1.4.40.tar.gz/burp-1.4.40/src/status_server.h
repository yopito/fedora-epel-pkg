#ifndef STATUS_SERVER_H
#define STATUS_SERVER_H

extern int status_server(int *cfd, struct config *conf);

#endif
