#undef  VERSION
#define VERSION "1.4.40"
