#ifdef WIN32_VSS
#define B_VSS_XP
#include "vss_generic.cpp"
#endif
