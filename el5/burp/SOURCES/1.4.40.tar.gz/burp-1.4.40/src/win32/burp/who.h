#define APP_NAME "Burp" 
#define LC_APP_NAME "burp"
#define APP_DESC "Burp Service"

extern void VSSInit();
