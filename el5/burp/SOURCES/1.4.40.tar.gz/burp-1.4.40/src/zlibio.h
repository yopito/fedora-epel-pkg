#ifndef _ZLIBIO_H
#define _ZLIBIO_H

extern int zlib_inflate(FILE *source, FILE *dest);

#endif
